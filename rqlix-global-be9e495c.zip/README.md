# Rqlix cosmetics audio overlay

First-party, procedurally synthesized interaction cues for `RqlixCosmetics`. No third-party
samples are used. Source and generated output may be redistributed with RqlixMC.

The unified-pack builder needs one central hook: merge the contents of this directory into its
stage after vendor payloads and before verification. The directory is intentionally separate from
`overlays/global` so parallel work cannot mutate the production overlay until that hook is reviewed.

Regenerate the OGG files with:

```sh
python3 resourcepack/tools/generate_cosmetic_sounds.py
```

The plugin plays these namespaced events only for Java clients known to have loaded the global
pack. Bedrock and no-pack clients receive the configured vanilla fallback cues.
