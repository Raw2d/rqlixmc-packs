# Modrinth cosmetics bundle

These are the exact upstream archives requested for the RqlixMC global pack on 2026-09-10.
They are inputs to `resourcepack/tools/merge_modrinth_cosmetics.py`; never serve them as stacked
packs. The merger preserves the global pack's `pack.mcmeta`, namespaces, item dispatches, and font
providers.

| Project | Version | SHA-1 | License |
|---|---|---|---|
| [Chain Accessories](https://modrinth.com/resourcepack/chain-accessories-resource-pack) | v1.0 | `477099773460e45a706b4612c419eae29ba4a928` | Apache-2.0 |
| [CodyTravis' HUD Resprite](https://modrinth.com/resourcepack/codytravis-hud-resprite) | 1.0.1 | `cea12316683691134f241be8378135e2f1e671f4` | MIT |
| [serv's hotbar GUI/HUD](https://modrinth.com/resourcepack/servs-hotbar-gui-hud-ui-whatever-(appleskin)) | 2.0 | `caa9338dd0882e169f686182e82e1658f00a0598` | GPL-3.0-or-later |
| [Mob Crates](https://modrinth.com/resourcepack/mob-crates) | 26.2 v2.4 | `4232c6448507c4d85558d0a403637f2f15810b76` | MIT |
| [Mini Mob Spawn Eggs](https://modrinth.com/resourcepack/mini-mob-spawn-eggs) | 1.3 | `fc15ef7eeed9159e9e7d70343312d1f35bb2c158` | MIT |
| [Baby Backport + Rabbits](https://modrinth.com/resourcepack/baby-backport-%2B-rabbits-(26.1)) | v1 | `9e8bd03d8cddb808b263396a690b0479b6239cd6` | LGPL-3.0-only |
| [East Slavic Fairy Tales](https://modrinth.com/resourcepack/east-slavic-fairy-tales) | 1.1 | `3c0e5b9853a5ebad521a0587ccded40954386404` | MIT |
| [Xiaowu's Better Boss Bar](https://modrinth.com/resourcepack/xiaowus-better-boss-bar) | 4.0 (1.19) | `72000bfd57391993ddf40f22ecc88dba12502a95` | Apache-2.0 in Modrinth metadata |

The Apache, GPL, and LGPL license texts are stored beside this file. MIT projects retain their
project links, author names, version, and hashes here and in the generated pack notice.

## Compatibility notes

- Chain Accessories' wearable behavior requires its separate datapack. This bundle adds only the
  requested resource-pack half.
- Baby Backport and East Slavic Fairy Tales require EMF or OptiFine for their custom entity models.
  Vanilla Java clients and Geyser do not execute OptiFine CEM files.
- Better Boss Bar is an old 1.19 pack. Its font providers and language mappings are merged instead
  of replacing the network font, and the normal global verifier must pass before publication.
- CodyTravis owns the shared health/food/armor/air/XP sprites. Serv owns its non-overlapping hotbar,
  crosshair, status-effect, jump-bar, and AppleSkin files.
- Mob Crates owns ordinary spawn-egg textures. Mini Mob Spawn Eggs retains its models and supplies
  the Ender Dragon, Wither, Warden, Iron Golem, and Snow Golem eggs. East Slavic Fairy Tales owns the
  Creaking, Phantom, and Witch eggs.
